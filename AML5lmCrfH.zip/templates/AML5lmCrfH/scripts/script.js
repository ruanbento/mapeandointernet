//delay 7 min script

setTimeout(function() {
  var scriptElement = document.getElementById('delay-script');
  scriptElement.src = 'caminho/do/seu/script.js';
}, 7 * 60 * 1000); // 7 minutos em milissegundos

// pessoas assistindo ao vídeo
function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

var startValue = generateRandomNumber(1500, 2000);
var currentValue = startValue;
var startTime = Date.now();
var growthChance = 0.6; // Chance de crescimento (60%)
var minIncrement = 1; // Incremento mínimo
var maxIncrement = 6; // Incremento máximo

document.getElementById("watchCount").textContent = currentValue;

function updateWatchCount() {
    var currentTime = Date.now();
    var elapsedTime = currentTime - startTime;

    var increment = generateRandomNumber(minIncrement, maxIncrement);
    var random = Math.random();

    if (random <= growthChance) {
        currentValue += increment;
    } else {
        currentValue -= increment;
    }

    document.getElementById("watchCount").textContent = currentValue;
}

// Atualiza o número a cada 1 segundo
setInterval(updateWatchCount, 2000);


// Função que formata a data no formato desejado


// **Função restam x vagas

function startDelayedTimer(startNumber, endNumber, duration, delay) {
    setTimeout(function() {
      const counterElement = document.getElementById('counter');
      const startTime = Date.now();
      const interval = 1000 / 60; // Aproximadamente 60 atualizações por segundo para uma transição suave
  
      const timerInterval = setInterval(function() {
        const currentTime = Date.now();
        const elapsedTime = currentTime - startTime;
  
        if (elapsedTime >= duration) {
          clearInterval(timerInterval);
          counterElement.textContent = `últimas ${endNumber} vagas`;
        } else {
          const progress = elapsedTime / duration;
          const currentValue = Math.round(startNumber + (progress * (endNumber - startNumber)));
          counterElement.textContent = `${currentValue}`;
        }
      }, interval);
    }, delay);
  }
  
  const initialNumber = 47;
  const finalNumber = 3;
  const timerDuration = 420000; // 7min duração
  const timerDelay = 000; // 1s de atraso
  
  startDelayedTimer(initialNumber, finalNumber, timerDuration, timerDelay);
  
  